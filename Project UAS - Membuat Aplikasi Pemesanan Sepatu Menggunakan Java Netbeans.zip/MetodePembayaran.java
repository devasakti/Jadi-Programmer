/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package materiform;

/**
 *
 * @author brandysign
 */
public class MetodePembayaran {
    public String metode,keterangan;

    public String getMetode() {
        return metode;
    }

    public void setMetode(String metode) {
        this.metode = metode;
    }

    public String getKeterangan() {
        return keterangan;
    }

    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }
    
    public void pilih (String metode){
         if(metode.equalsIgnoreCase("Cash"))
            keterangan="5 Hari Pengiriman Setelah Pre-Order";
        else if(metode.equalsIgnoreCase("Debit"))
            keterangan="3 Hari Pengiriman Setelah Pre-Order ";
        else if(metode.equalsIgnoreCase("Kredit"))
            keterangan="7 Hari Pengiriman Setelah Pre-Order";
        else
            keterangan="";
    }
}
